import tkinter as tk
from tkinter import messagebox, filedialog
import threading
import os
import shutil
import time

# === Глобальные переменные ===
folder_to_scan = ""
backup_folder = ""
restored_folder = ""
stop_flag = False

# === Проверка повреждения ===
def is_possibly_damaged(filepath):
    try:
        with open(filepath, "rb") as f:
            header = f.read(4)
            if filepath.lower().endswith((".doc", ".docx")):
                return not header.startswith(b'\xd0\xcf\x11\xe0') and not header.startswith(b'PK')
            elif filepath.lower().endswith(".pdf"):
                return not header.startswith(b'%PDF')
            elif filepath.lower().endswith(".xlsx"):
                return not header.startswith(b'PK')
            elif filepath.lower().endswith((".jpg", ".jpeg")):
                return not (header.startswith(b'\xff\xd8\xff\xe0') or header.startswith(b'\xff\xd8\xff'))
            else:
                return True
    except Exception:
        return True

# === Сканирование ===
def scan_files():
    global stop_flag
    if not folder_to_scan:
        messagebox.showwarning("Error", "Please select a folder to scan.")
        return

    stop_flag = False
    damaged_files = []
    start = time.time()
    log_output.delete(1.0, tk.END)
    log_output.insert(tk.END, "🔍 Scanning started...\n")

    log_path = os.path.join(folder_to_scan, "restore_log.txt")
    damaged_path = os.path.join(folder_to_scan, "damaged_files.txt")

    with open(log_path, "w", encoding="utf-8") as log, open(damaged_path, "w", encoding="utf-8") as damaged:
        for root_dir, _, files in os.walk(folder_to_scan):
            for file in files:
                if stop_flag:
                    log_output.insert(tk.END, "⛔ Scanning stopped by user.\n")
                    return

                if file.lower().endswith((".doc", ".docx", ".pdf", ".xlsx", ".jpg", ".jpeg")):
                    full_path = os.path.join(root_dir, file)
                    if is_possibly_damaged(full_path):
                        log.write(f"⚠️ Damaged: {full_path}\n")
                        damaged.write(full_path + "\n")
                        damaged_files.append(full_path)
                        log_output.insert(tk.END, f"⚠️ Damaged: {file}\n")
                    else:
                        log_output.insert(tk.END, f"✅ OK: {file}\n")

    elapsed = time.time() - start
    log_output.insert(tk.END, f"\n✅ Scan completed in {elapsed:.1f} sec. Damaged: {len(damaged_files)}\n")
    messagebox.showinfo("Scan completed", f"Damaged files found: {len(damaged_files)}")

# === Восстановление ===
def restore_files():
    if not all([folder_to_scan, backup_folder, restored_folder]):
        messagebox.showwarning("Error", "Please select a recovery folder.")
        return

    damaged_path = os.path.join(folder_to_scan, "damaged_files.txt")
    if not os.path.exists(damaged_path):
        messagebox.showerror("Error", "File damaged_files.txt not found. Please run scan firts.")
        return

    restored_count = 0
    missing_count = 0

    restored_path = os.path.join(folder_to_scan, "restored_files.txt")
    missing_path = os.path.join(folder_to_scan, "missing_files.txt")

    with open(damaged_path, "r", encoding="utf-8") as damaged, \
         open(restored_path, "w", encoding="utf-8") as restored_log, \
         open(missing_path, "w", encoding="utf-8") as missing_log:

        for line in damaged:
            original = line.strip()
            rel_path = os.path.relpath(original, folder_to_scan)
            backup_file = os.path.join(backup_folder, rel_path)
            restore_target = os.path.join(restored_folder, rel_path)

            os.makedirs(os.path.dirname(restore_target), exist_ok=True)

            if os.path.exists(backup_file):
                shutil.copy2(backup_file, restore_target)
                restored_log.write(f"{restore_target}\n")
                log_output.insert(tk.END, f"🔄 Restored: {rel_path}\n")
                restored_count += 1
            else:
                missing_log.write(f"{rel_path}\n")
                missing_count += 1

    log_output.insert(tk.END, f"\n✅ Restored: {restored_count}\n❌ Not found in backup: {missing_count}\n")
    messagebox.showinfo("Restoration Complete", f"Restored: {restored_count}, Not Found: {missing_count}")

# === Потоки ===
def start_scan_thread():
    threading.Thread(target=scan_files).start()

def start_restore_thread():
    threading.Thread(target=restore_files).start()

def stop_scan():
    global stop_flag
    stop_flag = True

# === Выбор папок ===
def select_scan_folder():
    global folder_to_scan
    folder_to_scan = filedialog.askdirectory(title="Choose scan folder")
    log_output.insert(tk.END, f"📁 Scan folder: {folder_to_scan}\n")

def select_backup_folder():
    global backup_folder
    backup_folder = filedialog.askdirectory(title="Choose backup folder")
    log_output.insert(tk.END, f"📁 Backup folder: {backup_folder}\n")

def select_restore_folder():
    global restored_folder
    restored_folder = filedialog.askdirectory(title="Choose recovery folder")
    log_output.insert(tk.END, f"📁 Recovery folder: {restored_folder}\n")

# === Информация о программе ===
def show_about_window():
    about_win = tk.Toplevel(root)
    about_win.title("About Program")
    about_win.geometry("480x280")
    about_win.resizable(False, False)
    
    about_text = (
        "🔧 Recovery Tool\n\n"
        "Program is intended for:\n"
        "— File Scan (.doc, .docx, .pdf, .xlsx, .jpg, .jpeg)\n"
        "— Definitions of damaged files\n"
        "— Restore frome backup folder\n\n"
        "👤 Author: Chybisov Mykhail\n"
        "🗓️ Version: 1.0\n"
        "📅 Date: 10.07.2025\n"
    )

    label = tk.Label(about_win, text=about_text, justify="left", font=("Arial", 11), padx=20, pady=20)
    label.pack(fill="both", expand=True)

# === Интерфейс ===
root = tk.Tk()
root.title("🛠️ Recovery Tool Program")
root.geometry("1100x700")

btn_style = {"width": 24, "height": 2, "font": ("Arial", 11)}

# Верхние кнопки выбора директорий
path_frame = tk.Frame(root)
path_frame.pack(pady=10)

tk.Button(path_frame, text="📂 Scan Folder", command=select_scan_folder, **btn_style).pack(side="left", padx=5)
tk.Button(path_frame, text="🗃️ Backup Folder", command=select_backup_folder, **btn_style).pack(side="left", padx=5)
tk.Button(path_frame, text="📁 Recovery Folder", command=select_restore_folder, **btn_style).pack(side="left", padx=5)

# Кнопки действий
action_frame = tk.Frame(root)
action_frame.pack(pady=10)

tk.Button(action_frame, text="🔍 Scan", command=start_scan_thread, **btn_style).pack(side="left", padx=5)
tk.Button(action_frame, text="⛔ Stop", command=stop_scan, **btn_style).pack(side="left", padx=5)
tk.Button(action_frame, text="🔄 Recover", command=start_restore_thread, **btn_style).pack(side="left", padx=5)
tk.Button(action_frame, text="🚪 Exit", command=root.destroy, **btn_style).pack(side="left", padx=5)

# Вывод логов
log_output = tk.Text(root, height=25, wrap="word", font=("Consolas", 10))
log_output.pack(expand=True, fill="both", padx=15, pady=10)

# Нижняя панель
bottom_frame = tk.Frame(root)
bottom_frame.pack(pady=5)
tk.Button(bottom_frame, text="ℹ️ About Program", command=show_about_window, font=("Arial", 10)).pack()

root.mainloop()